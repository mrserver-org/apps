function doomgame() {
	createWindow("DOOM (buggy)", `
	<style type="text/css">
      .dosbox-container { width: 100%; }
      .dosbox-container > .dosbox-overlay { background: url(https://js-dos.com/cdn/DOOM.png); }
	  .container {width: 100%}
    </style>
	<div class="container">
	<div style="width: 100%;" id="dosbox"></div>
	</div>
	<button onclick="document.querySelector('.dosbox-start').click();">Start</button>
	<button onclick="dosbox.requestFullScreen();">Fullscreen</button>
	`);
	
    var dosbox = new Dosbox({
      id: "dosbox",
      onload: function (dosbox) {
        dosbox.run("/3rd_party_apps/doom-assets/game.zip", "./DOOM/DOOM.EXE");
      },
      onrun: function (dosbox, app) {
        console.log("App '" + app + "' is runned");
      }
    });
	expose(dosbox);
}