function pywal() {
    const win = createWindow("Pywal Configurator", `        
        <div class="pywal-main">
            <div class="toggle-container">
                <div class="toggle-label">Enable Pywal Theme</div>
                <label class="toggle-switch">
                    <input type="checkbox" id="pywalToggle" ${localStorage.getItem("pywal") === "true" ? "checked" : ""}>
                    <span class="toggle-slider"></span>
                </label>
            </div>
        </div>
    </div>
    <style>
        .pywal-container {
            display: flex;
            flex-direction: column;
            height: 100%;
            overflow: hidden;
        }
        .pywal-main {
            flex: 1;
            padding: 24px;
            display: flex;
            flex-direction: column;
            gap: 24px;
            align-items: center;
            justify-content: center;
        }
        
        .toggle-container {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .toggle-label {
            font-size: 18px;
            font-weight: bold;
        }
        
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }
        
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: var(--accent);
            transition: .4s;
            border-radius: 34px;
        }
        
        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: #f8f8f2;
            transition: .4s;
            border-radius: 50%;
        }
        
        input:checked + .toggle-slider {
            background-color: var(--accent);
        }
        
        input:checked + .toggle-slider:before {
            transform: translateX(26px);
        }
    </style>
`);
        const toggle = win.querySelector('#pywalToggle');
        const statusText = win.querySelector('#statusText');
        const applyBtn = win.querySelector('#applyBtn');
        
        toggle.addEventListener('change', function() {
			togglePywal(this.checked);
        });
}

function togglePywal(enabled) {
  if (enabled) {
    let homedir = "";
    fetch(`http://${window.location.hostname}:9091/api/terminal_exec?command=bash -c "cd;pwd"`).then(response => response.text()).then(data => {
        homedir = data.trim();
        fetch('http://' + window.location.hostname + ':9091/api/terminal_exec?command=cat ' + encodeURIComponent(`${homedir}/.cache/wal/colors.css`))
      .then(response => response.text())
      .then(data => {
        const styleElement = document.createElement('style');
        styleElement.id = 'pywal-theme';
        styleElement.textContent = `${data}:root{--accent:var(--color1);--bg-color:var(--color0);--window-bg:var(--background);--text:var(--foreground);--border:var(--color0); --window-header: var(--color1);}`;
        document.head.appendChild(styleElement);
        const desktop = document.getElementById('desktop');
        const raw = getComputedStyle(desktop).getPropertyValue('--wallpaper').trim();
        const mrcredentials = JSON.parse(localStorage.getItem('credentials'));
        const match = raw.match(/url\(["']?(.*?)["']?\)/);
        const wallpaper = match ? match[1] : null;
        const url =
      "http://" +
      window.location.host.split(":")[0] +
      ":9091" +
      "/api/file_manager/download" +
      `?path=${encodeURIComponent(wallpaper)}&username=${mrcredentials.username}&password=${mrcredentials.password}`;
        styleElement.textContent += `#desktop{background:url("${url}") center/cover}.start-sidebar{color:var(--text)}`;
        localStorage.setItem('pywal', 'true');
    }).catch(error => console.error('Error loading pywal theme:', error));
    }).catch(error => console.error('Error fetching home directory: ', error));
  } else {
    const existingStyle = document.getElementById('pywal-theme');
    if (existingStyle) {
      existingStyle.remove();
    }
    localStorage.setItem('pywal', 'false');
  }
}

function isPywalEnabled() {
  return localStorage.getItem('pywal') === 'true';
}

function initializePywal() {
  const enabled = isPywalEnabled();
  togglePywal(enabled);
}

initializePywal();