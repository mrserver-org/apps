function testitout() {
	createWindow("Test", `
	<h1>HELLO</h1>
	`, 400, 300);
}